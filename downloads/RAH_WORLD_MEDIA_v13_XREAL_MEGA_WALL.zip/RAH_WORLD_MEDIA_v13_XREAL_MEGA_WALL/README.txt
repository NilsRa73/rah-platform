RAH WORLD MEDIA 13.0 — XREAL MEGA WALL
=======================================

Purpose
-------
Windows/Python command deck for public/legal World TV, World Radio and webcams, with a dedicated ultrawide XREAL mode.

XREAL MODE
----------
Use the new "XREAL MODE" button after TV data has loaded. It opens a browser HUD designed for XREAL One and ultrawide monitors.

- VISIBLE TILES: choose 1–500.
- LIVE LIMIT: choose 1–256 simultaneous HLS decoders.
- 64 active feeds is the recommended first ceiling.
- 96–256 is experimental and depends heavily on GPU video decode, stream bitrate, browser and network.
- 500 WALL means up to 500 tiles can be visible, while only LIVE LIMIT tiles actively decode video.
- NEXT BANK rotates the active live set.
- AUTO 10s automatically rotates live banks.
- Click any tile for CLEAN CINEMA. Only the selected stream gets audio.

XREAL ONE
---------
Treat the glasses as an ultrawide personal display. In Windows use Extend, and in the XREAL OSD try Anchor + UltraWide. The RAH page itself does not provide Quest-style standalone VR; the Windows PC renders the HUD.

OTHER FEATURES
--------------
World Live, Super Search, Media Wall, Radio, Webcams, presets, My Library, token-protected Remote Deck and Raven Sync Receiver are retained from v12.

SAFETY / LEGAL
--------------
Public/legal streams and user-owned/authorized playlists only. No DRM, paywall or geo-restriction bypass. LAN receiver access remains explicit opt-in and token-protected.

START
-----
1. Extract the ZIP.
2. Double-click START-HER.cmd.
3. Wait for TV catalog loading.
4. Click XREAL MODE.
5. Start with 64 visible / 16–32 live, then increase LIVE LIMIT gradually.

Optional INSTALL.cmd installs under C:\RAH\WorldMedia\13.0 and creates shortcuts.
