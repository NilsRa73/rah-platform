@echo off
setlocal
cd /d "%~dp0"
title RAH World Media v13.0 XREAL MEGA WALL - SELFTEST
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RAH_BOOTSTRAP.ps1" -SelfTest
exit /b %errorlevel%
