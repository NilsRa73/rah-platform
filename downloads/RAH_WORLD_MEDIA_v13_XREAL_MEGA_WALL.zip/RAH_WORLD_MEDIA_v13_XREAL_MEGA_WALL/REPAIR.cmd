@echo off
setlocal
cd /d "%~dp0"
title RAH World Media v13.0 XREAL MEGA WALL - REPAIR
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RAH_BOOTSTRAP.ps1" -Repair
exit /b %errorlevel%
