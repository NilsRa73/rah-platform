@echo off
setlocal
cd /d "%~dp0"
title RAH World Media v6.0 - REPAIR
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RAH_BOOTSTRAP.ps1" -Repair
exit /b %errorlevel%
