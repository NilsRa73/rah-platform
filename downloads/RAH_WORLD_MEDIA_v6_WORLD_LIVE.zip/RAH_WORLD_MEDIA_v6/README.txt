RAH WORLD MEDIA v6.0 — WORLD LIVE COMMAND DECK
===============================================

TV + RADIO + WEBCAMS + INTERACTIVE GLOBE + MEDIA WALL + TV MOSAIC + WORLD LIVE

START
1. Double-click START-HER.cmd
2. The launcher finds a working Python 3 + tkinter, compiles the app, writes logs under C:\RAH\IPTV\logs and launches it.
3. REPAIR.cmd can offer Winget install of missing Python/VLC.

NEW IN v6
- WORLD LIVE autopilot: automatically hops between media-rich countries on the globe.
- Automatic hop is intentionally gentle (18 seconds) and pauses when you manually drag the globe.
- Explicit TV MOSAIC in the browser Media Wall: 4 / 6 / 9 simultaneous muted HLS mini-screens.
- Click one mosaic tile to make only that tile audible; others remain muted.
- Webcam themed channels: Northern Lights, Weather, Traffic, Beaches, Harbors, Mountains and City.
- Favorite webcams persist as brighter globe pins across countries.
- "Pin city" persists a webcam city/location as a gold diamond on the globe.
- World Live does not spend Windy Webcams API quota while automatically hopping. Webcams remain on-demand.
- v5 history/favorites remain compatible; v6 migrates v5 globe state automatically on first run.

MEDIA WALL / MOSAIC
Select a country and press MEDIA WALL or TV MOSAIC.
The local page is written to:
  C:\RAH\IPTV\media_wall_v6.html
Use the 4 / 6 / 9 controls in the header. Only public streams that allow browser HLS/CORS can appear; VLC playback can still work when a browser preview cannot.

WORLD LIVE
Turn on WORLD LIVE in the top bar, HOME, or GLOBE toolbar.
The globe centers on a media-rich country, loads local TV and radio previews, and hops again after about 18 seconds. Manual dragging pauses World Live.

WEBCAM CHANNELS
Windy Webcams API v3 is optional and requires an API key. Use the in-app key button or WINDY_WEBCAMS_API_KEY.
The key is stored only on your PC under C:\RAH\IPTV when entered in-app.
Webcam preview imagery/links are used as returned by Windy and retain Windy attribution.

DATA SOURCES
- TV + logos: iptv-org public APIs
- Radio: Radio Browser public API with mirror fallback
- Webcams: Windy Webcams API v3 when configured
- Radio Garden: official site opened externally

LEGAL / NETWORK
Uses public/legal streams and user-authorized M3U imports. Follows the active Windows network/VPN route. Does not bypass DRM, subscriptions, paywalls, geo restrictions or access controls.

RUN
- Main: START-HER.cmd
- Optional diagnostics: SELFTEST.cmd
- Optional repair: REPAIR.cmd
