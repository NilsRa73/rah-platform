RAH WORLD MEDIA v4.0 — TV + RADIO + WEBCAMS
===============================================

NEW IN V4
- WEBCAMS as a first-class category.
- Optional Windy Webcams API v3 integration.
- Webcam points appear as gold dots on the globe for the selected country.
- Separate WEBCAMS tab with country loading, search/filter, favorites and browser player/source opening.
- Globe layer selector: ALL / TV / RADIO / WEBCAMS.
- TV and radio from v3 remain intact.

START
  START-RAH-WORLD-MEDIA.cmd

TEST
  SELFTEST.cmd

WEBCAMS
Windy Webcams API requires an API key. The app never embeds a key in code.
Preferred: set environment variable WINDY_WEBCAMS_API_KEY.
Or use the in-app “Windy API key” button; it stores the key locally under:
  C:\RAH\IPTV\windy_webcams_api_key.txt

Get API information/key at:
  https://api.windy.com/

Without a Windy key, the app still runs normally and TV/radio are unaffected.
The Webcams tab remains available and offers an external Windy Webcams link.

Webcam images/player links are used as returned by Windy and are not copied into the package.
Attribution: Webcams provided by Windy.com.

TV source: iptv-org public catalog
Radio source: Radio Browser API
Webcams: Windy Webcams API v3 when configured

VPN
The program does not control VPN or bypass DRM, subscriptions, paywalls or access controls.
Playback follows the active Windows network/VPN routing.
