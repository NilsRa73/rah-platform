@echo off
setlocal
title RAH World TV + Radio v4
cd /d "%~dp0"

where py >nul 2>&1
if %errorlevel%==0 (
  py -3 RAH_WORLD_MEDIA.py
  goto :eof
)

where python >nul 2>&1
if %errorlevel%==0 (
  python RAH_WORLD_MEDIA.py
  goto :eof
)

echo.
echo Python ble ikke funnet.
echo Installer Python 3 fra https://www.python.org/downloads/
echo Huk av "Add Python to PATH".
echo.
pause
