RAH WORLD MEDIA v5.0 — GOLD COMMAND DECK
==========================================

TV + RADIO + WEBCAMS + INTERACTIVE GLOBE + MEDIA WALL

START
1. Double-click START-HER.cmd
2. The launcher automatically finds a real working Python installation, checks tkinter,
   compiles the app, writes a log under C:\RAH\IPTV\logs, then launches the app.
3. If Python is missing, the launcher can offer a Winget install.

OPTIONAL
- SELFTEST.cmd   : local checks + lightweight network smoke tests
- REPAIR.cmd     : offers to install missing Python/VLC through Winget
- START-RAH-WORLD-MEDIA.cmd : compatibility shortcut to START-HER.cmd

WHAT IS NEW IN v5
- New HOME / Command Deck dashboard.
- Quick Jump country selector.
- Surprise Country button.
- Smooth globe auto-rotation toggle.
- Media Wall: premium browser-based grid for the selected country.
- Small muted HLS TV previews start only on hover and max 2 play at once.
- Full browser theater player from the Media Wall.
- IPTV-org channel logos loaded from the official logos API.
- Radio Browser mirror fallback instead of relying on one server only.
- Recent TV / radio / webcam history stored locally.
- TV + Radio + Webcams remain integrated into the interactive globe.
- Robust Python discovery to avoid Windows App Execution Alias / PATH problems.

MEDIA WALL
Select a country on the globe, then press "MEDIA WALL".
It creates a local black/gold page under:
  C:\RAH\IPTV\media_wall_v5.html

TV cards show channel logos and can run a muted HLS preview on hover when the
stream allows browser playback/CORS. Preview failure never affects VLC playback
inside the Python app.

WEBCAMS
Windy Webcams API v3 requires an API key.
Set WINDY_WEBCAMS_API_KEY or use the in-app "Windy API key" button.
The key is stored only on this PC under:
  C:\RAH\IPTV\windy_webcams_api_key.txt

Without a key, TV and radio continue to work normally.
Webcam images/links are used as returned by Windy and the UI includes Windy attribution.

DATA SOURCES
- TV: iptv-org public API
- TV logos: iptv-org logos API
- Radio: Radio Browser public API with mirror fallback
- Webcams: Windy Webcams API v3 when configured
- Radio Garden: official site opened externally

NETWORK / VPN
RAH World Media follows the active Windows network/VPN route.
It does not bypass DRM, subscriptions, paywalls, geo restrictions or access controls.

LOCAL STORAGE
RAH state, favorites, cache, history, logs and Media Wall live under:
  C:\RAH\IPTV\

RUN CHECKLIST
- Main file to run: START-HER.cmd
- Optional diagnostic: SELFTEST.cmd
- Optional repair: REPAIR.cmd
- Success: HOME tab opens and TV/radio catalogs begin loading.
- Do not manually run RAH_BOOTSTRAP.ps1 unless you want PowerShell diagnostics.
