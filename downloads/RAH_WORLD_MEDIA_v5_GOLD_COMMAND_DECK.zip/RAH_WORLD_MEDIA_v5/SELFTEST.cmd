@echo off
setlocal
cd /d "%~dp0"
title RAH World Media v5.0 - SELFTEST
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0RAH_BOOTSTRAP.ps1" -SelfTest
exit /b %errorlevel%
