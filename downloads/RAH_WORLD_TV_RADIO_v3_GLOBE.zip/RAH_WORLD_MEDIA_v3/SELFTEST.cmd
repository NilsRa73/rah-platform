@echo off
setlocal
title RAH World TV + Radio v3 - SELFTEST
cd /d "%~dp0"
echo ============================================================
echo   RAH WORLD TV + RADIO v3.0 - SELFTEST
echo ============================================================
echo.

set FAIL=0
set PY=

where py >nul 2>&1
if %errorlevel%==0 set PY=py -3

if not defined PY (
  where python >nul 2>&1
  if %errorlevel%==0 set PY=python
)

if not defined PY (
  echo FAIL: Python ble ikke funnet.
  set FAIL=1
) else (
  echo PASS: Python funnet.
  %PY% -m py_compile RAH_WORLD_MEDIA.py
  if errorlevel 1 (
    echo FAIL: Python syntax/compile.
    set FAIL=1
  ) else (
    echo PASS: RAH_WORLD_MEDIA.py compile.
  )
)

if exist world_countries_simplified.json (
  echo PASS: world_countries_simplified.json funnet.
) else (
  echo FAIL: world_countries_simplified.json mangler.
  set FAIL=1
)

set VLC=
if exist "%ProgramFiles%\VideoLAN\VLC\vlc.exe" set VLC=%ProgramFiles%\VideoLAN\VLC\vlc.exe
if exist "%ProgramFiles(x86)%\VideoLAN\VLC\vlc.exe" set VLC=%ProgramFiles(x86)%\VideoLAN\VLC\vlc.exe
where vlc >nul 2>&1
if %errorlevel%==0 set VLC=vlc

if defined VLC (
  echo PASS: VLC funnet.
) else (
  echo WARN: VLC mangler. Appen kan starte, men PLAY krever VLC.
)

echo.
if "%FAIL%"=="0" (
  echo ============================================================
  echo RAH WORLD MEDIA v3: PASS
  echo ============================================================
) else (
  echo ============================================================
  echo RAH WORLD MEDIA v3: FAIL
  echo ============================================================
)
echo.
pause
exit /b %FAIL%
