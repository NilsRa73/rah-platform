RAH WORLD TV + RADIO v3.0
=========================

NEW IN V3:
- Interactive world globe inside the app.
- Clickable countries.
- Selected country shows available TV streams and radio stations.
- Drag globe to rotate, mouse wheel to zoom.
- Buttons to jump directly from globe to the full TV or Radio tabs for the selected country.

START:
  START-RAH-WORLD-MEDIA.cmd

TEST:
  SELFTEST.cmd

INNHOLD:
- WORLD TV fra iptv-org offentlige IPTV-katalog.
- WORLD RADIO fra Radio Browser sitt offentlige API.
- Egen knapp til Radio Garden sin interaktive globus.
- Innebygd globe med klikkbare land.
- Land, søk, tags, språk/region, codec, bitrate og favoritter.
- M3U/M3U8-import.
- Avspilling i VLC.
- Cache og brukerdata under C:\RAH\IPTV
VPN:
Programmet styrer ikke VPN og prøver ikke å omgå DRM, abonnement eller betalingsmurer.
Når system-VPN er aktiv, følger VLC og Python normalt Windows sin aktive ruting.
