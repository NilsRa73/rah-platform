#!/usr/bin/env python3
# RAH World TV + Radio v3.0
# Adds an interactive globe with clickable countries and media previews.

from __future__ import annotations

import json
import math
import os
import queue
import re
import shutil
import subprocess
import threading
import time
import urllib.parse
import urllib.request
import webbrowser
from dataclasses import dataclass
from pathlib import Path
from tkinter import Tk, StringVar, BooleanVar, END, BOTH, LEFT, RIGHT, X, Y, VERTICAL, HORIZONTAL
from tkinter import ttk, messagebox, filedialog

APP_NAME = "RAH World TV + Radio"
VERSION = "3.0"
APP_DIR = Path(__file__).resolve().parent
WORLD_FILE = APP_DIR / "world_countries_simplified.json"
BASE_DIR = Path(os.environ.get("RAH_IPTV_HOME", r"C:\RAH\IPTV"))
CACHE_DIR = BASE_DIR / "cache"
STATE_FILE = BASE_DIR / "state_v3.json"
TV_FAV_FILE = BASE_DIR / "favorites_tv.json"
RADIO_FAV_FILE = BASE_DIR / "favorites_radio.json"
CUSTOM_FILE = BASE_DIR / "custom_channels.json"

TV_API = {
    "channels": "https://iptv-org.github.io/api/channels.json",
    "streams": "https://iptv-org.github.io/api/streams.json",
    "countries": "https://iptv-org.github.io/api/countries.json",
    "categories": "https://iptv-org.github.io/api/categories.json",
}
RADIO_API = "https://de1.api.radio-browser.info"

GOLD = "#d7ad42"
GOLD2 = "#a9832e"
BG = "#0b0c0e"
PANEL = "#14161a"
PANEL2 = "#1d2025"
TEXT = "#f1ead8"
MUTED = "#a9a390"
ACCENT = "#f8d26a"
OCEAN = "#0e1520"
GRID = "#233042"


@dataclass
class TVChannel:
    id: str
    name: str
    country: str
    country_name: str
    categories: list[str]
    url: str
    quality: str
    labels: list[str]
    website: str = ""
    source: str = "iptv-org"

    @property
    def category_text(self):
        return ", ".join(self.categories) if self.categories else "general"

    @property
    def label_text(self):
        return ", ".join(self.labels)


@dataclass
class RadioStation:
    uuid: str
    name: str
    country: str
    countrycode: str
    state: str
    language: str
    tags: str
    codec: str
    bitrate: int
    url: str
    homepage: str
    favicon: str
    votes: int
    clickcount: int


def ensure_dirs():
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    CACHE_DIR.mkdir(parents=True, exist_ok=True)


def read_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def http_json(url: str, timeout=35):
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": f"RAH-World-TV-Radio/{VERSION}",
            "Accept": "application/json",
        },
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", errors="replace"))


def fetch_tv_json(name: str, force=False, max_age_hours=8):
    ensure_dirs()
    p = CACHE_DIR / f"tv_{name}.json"
    if p.exists() and not force:
        age = time.time() - p.stat().st_mtime
        if age < max_age_hours * 3600:
            return read_json(p, [])
    data = http_json(TV_API[name])
    write_json(p, data)
    return data


def locate_vlc():
    candidates = [
        shutil.which("vlc"),
        os.path.expandvars(r"%PROGRAMFILES%\VideoLAN\VLC\vlc.exe"),
        os.path.expandvars(r"%PROGRAMFILES(X86)%\VideoLAN\VLC\vlc.exe"),
        str(Path.home() / "scoop" / "apps" / "vlc" / "current" / "vlc.exe"),
    ]
    for p in candidates:
        if p and Path(p).exists():
            return p
    return None


def play_url(url: str):
    vlc = locate_vlc()
    if not vlc:
        raise FileNotFoundError("VLC ble ikke funnet")
    subprocess.Popen([vlc, "--one-instance", "--playlist-enqueue", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def normalize(s):
    return re.sub(r"\s+", " ", (s or "").strip()).casefold()


def parse_m3u(path: Path):
    text = path.read_text(encoding="utf-8", errors="ignore")
    out = []
    meta = None
    for raw in text.splitlines():
        line = raw.strip()
        if line.startswith("#EXTINF"):
            name = line.rsplit(",", 1)[-1].strip() or "Custom channel"
            group = ""
            m = re.search(r'group-title="([^"]*)"', line)
            if m:
                group = m.group(1)
            meta = (name, group)
        elif line and not line.startswith("#") and meta:
            name, group = meta
            out.append({
                "id": f"custom:{len(out)}:{name}",
                "name": name,
                "country": "CUSTOM",
                "country_name": "Custom M3U",
                "categories": [group] if group else ["custom"],
                "url": line,
                "quality": "",
                "labels": [],
                "website": "",
                "source": "custom",
            })
            meta = None
    return out


def blend(c1, c2, t):
    t = max(0.0, min(1.0, t))
    a = tuple(int(c1[i:i+2], 16) for i in (1, 3, 5))
    b = tuple(int(c2[i:i+2], 16) for i in (1, 3, 5))
    rgb = tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))
    return '#%02x%02x%02x' % rgb


def load_world_shapes():
    return read_json(WORLD_FILE, [])


class App:
    def __init__(self, root: Tk):
        self.root = root
        self.root.title(f"{APP_NAME} {VERSION}")
        self.root.geometry("1620x930")
        self.root.minsize(1150, 700)

        ensure_dirs()
        self.state = read_json(STATE_FILE, {})
        self.tv_favorites = set(read_json(TV_FAV_FILE, []))
        self.radio_favorites = set(read_json(RADIO_FAV_FILE, []))
        self.world_shapes = load_world_shapes()

        self.tv_channels = []
        self.tv_filtered = []
        self.radio_stations = []
        self.radio_filtered = []
        self.radio_countries = []
        self.radio_country_counts = {}
        self.tv_counts_by_iso = {}
        self.tv_country_name_by_iso = {}
        self.msgq = queue.Queue()
        self.tv_loading = False
        self.radio_loading = False
        self.globe_preview_loading = False
        self.globe_preview_request = 0
        self.globe_selected_iso = None
        self.globe_selected_name = None
        self.globe_tv_preview_items = []
        self.globe_radio_preview_items = []
        self.globe_hover_text = StringVar(value="Dra for å rotere globusen • Klikk et land")
        self.globe_selected_text = StringVar(value="No country selected")
        self.globe_selected_counts = StringVar(value="TV: 0 • Radio: 0")
        self.status_var = StringVar(value="Klar.")
        self.globe_lon0 = float(self.state.get("globe_lon0", 0.0))
        self.globe_lat0 = float(self.state.get("globe_lat0", 15.0))
        self.globe_zoom = float(self.state.get("globe_zoom", 1.0))
        self._drag_last = None
        self._skip_click = False

        self.setup_style()
        self.build_ui()
        self.root.after(120, self.poll_queue)

        self.load_tv_async()
        self.load_radio_countries_async()
        self.load_radio_async(mode="top")
        self.redraw_globe()

    def setup_style(self):
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        self.root.configure(bg=BG)
        style.configure(".", background=BG, foreground=TEXT, fieldbackground=PANEL2, font=("Segoe UI", 10))
        style.configure("TFrame", background=BG)
        style.configure("Panel.TFrame", background=PANEL)
        style.configure("TLabel", background=BG, foreground=TEXT)
        style.configure("Muted.TLabel", foreground=MUTED)
        style.configure("Title.TLabel", font=("Segoe UI Semibold", 21), foreground=GOLD)
        style.configure("Gold.TButton", background=GOLD2, foreground="#ffffff", padding=8)
        style.map("Gold.TButton", background=[("active", GOLD)])
        style.configure("TButton", background=PANEL2, foreground=TEXT, padding=7)
        style.map("TButton", background=[("active", "#2a2e35")])
        style.configure("TEntry", fieldbackground=PANEL2, foreground=TEXT, insertcolor=TEXT, padding=7)
        style.configure("TCombobox", fieldbackground=PANEL2, background=PANEL2, foreground=TEXT)
        style.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground=TEXT, rowheight=26, borderwidth=0)
        style.configure("Treeview.Heading", background=PANEL2, foreground=GOLD, relief="flat", font=("Segoe UI Semibold", 10))
        style.map("Treeview", background=[("selected", "#4a3c18")], foreground=[("selected", "#ffffff")])
        style.configure("TCheckbutton", background=BG, foreground=TEXT)
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", background=PANEL2, foreground=TEXT, padding=(18, 9))
        style.map("TNotebook.Tab", background=[("selected", GOLD2)], foreground=[("selected", "#ffffff")])

    def build_ui(self):
        top = ttk.Frame(self.root)
        top.pack(fill=X, padx=14, pady=(12, 8))
        ttk.Label(top, text="RAH WORLD MEDIA", style="Title.TLabel").pack(side=LEFT)
        ttk.Label(top, text="  Interactive globe • World TV • World Radio", style="Muted.TLabel").pack(side=LEFT, padx=10)
        ttk.Button(top, text="🌍 RADIO GARDEN", style="Gold.TButton", command=lambda: webbrowser.open("https://radio.garden/")).pack(side=RIGHT, padx=4)

        self.tabs = ttk.Notebook(self.root)
        self.tabs.pack(fill=BOTH, expand=True, padx=14, pady=(0, 8))
        self.globe_tab = ttk.Frame(self.tabs)
        self.tv_tab = ttk.Frame(self.tabs)
        self.radio_tab = ttk.Frame(self.tabs)
        self.tabs.add(self.globe_tab, text="🌐 GLOBE")
        self.tabs.add(self.tv_tab, text="📺 WORLD TV")
        self.tabs.add(self.radio_tab, text="📻 WORLD RADIO")

        self.build_globe_tab()
        self.build_tv_tab()
        self.build_radio_tab()

        footer = ttk.Frame(self.root)
        footer.pack(fill=X, padx=14, pady=(0, 10))
        ttk.Label(footer, text="RAH World Media • public/legal streams • no DRM bypass", style="Muted.TLabel").pack(side=LEFT)
        ttk.Label(footer, textvariable=self.status_var, style="Muted.TLabel").pack(side=RIGHT)

    # ---------- Globe ----------

    def build_globe_tab(self):
        wrap = ttk.Frame(self.globe_tab)
        wrap.pack(fill=BOTH, expand=True)
        wrap.columnconfigure(0, weight=3)
        wrap.columnconfigure(1, weight=2)
        wrap.rowconfigure(0, weight=1)

        left = ttk.Frame(wrap)
        left.grid(row=0, column=0, sticky='nsew', padx=(0, 10))
        left.rowconfigure(1, weight=1)
        left.columnconfigure(0, weight=1)

        toolbar = ttk.Frame(left)
        toolbar.grid(row=0, column=0, sticky='ew', pady=(6, 6))
        ttk.Label(toolbar, textvariable=self.globe_hover_text, style='Muted.TLabel').pack(side=LEFT)
        ttk.Button(toolbar, text='⟲ Reset globe', command=self.reset_globe).pack(side=RIGHT, padx=4)
        ttk.Button(toolbar, text='＋ Zoom', command=lambda: self.zoom_globe(1.1)).pack(side=RIGHT, padx=4)
        ttk.Button(toolbar, text='－ Zoom', command=lambda: self.zoom_globe(0.9)).pack(side=RIGHT, padx=4)

        self.globe_canvas = __import__('tkinter').Canvas(left, bg=BG, highlightthickness=0)
        self.globe_canvas.grid(row=1, column=0, sticky='nsew')
        self.globe_canvas.bind('<Configure>', lambda e: self.redraw_globe())
        self.globe_canvas.bind('<ButtonPress-1>', self.on_globe_press)
        self.globe_canvas.bind('<B1-Motion>', self.on_globe_drag)
        self.globe_canvas.bind('<ButtonRelease-1>', self.on_globe_release)
        self.globe_canvas.bind('<MouseWheel>', self.on_globe_wheel)
        self.globe_canvas.bind('<Button-4>', lambda e: self.zoom_globe(1.1))
        self.globe_canvas.bind('<Button-5>', lambda e: self.zoom_globe(0.9))

        right = ttk.Frame(wrap)
        right.grid(row=0, column=1, sticky='nsew')
        right.rowconfigure(4, weight=1)
        right.rowconfigure(6, weight=1)
        right.columnconfigure(0, weight=1)

        ttk.Label(right, text='Selected country', style='Muted.TLabel').grid(row=0, column=0, sticky='w', pady=(6, 2))
        ttk.Label(right, textvariable=self.globe_selected_text, style='Title.TLabel').grid(row=1, column=0, sticky='w')
        ttk.Label(right, textvariable=self.globe_selected_counts).grid(row=2, column=0, sticky='w', pady=(0, 8))

        btns = ttk.Frame(right)
        btns.grid(row=3, column=0, sticky='ew', pady=(0, 8))
        ttk.Button(btns, text='📺 Open TV for country', command=self.open_selected_country_tv).pack(side=LEFT, padx=(0, 6))
        ttk.Button(btns, text='📻 Open Radio for country', command=self.open_selected_country_radio).pack(side=LEFT)

        ttk.Label(right, text='TV streams in selected country', style='Muted.TLabel').grid(row=4, column=0, sticky='sw')
        tv_wrap = ttk.Frame(right)
        tv_wrap.grid(row=5, column=0, sticky='nsew', pady=(2, 8))
        tv_wrap.rowconfigure(0, weight=1)
        tv_wrap.columnconfigure(0, weight=1)
        self.globe_tv_tree = ttk.Treeview(tv_wrap, columns=('name','cat','q'), show='headings', height=8)
        self.globe_tv_tree.heading('name', text='Channel')
        self.globe_tv_tree.heading('cat', text='Category')
        self.globe_tv_tree.heading('q', text='Q')
        self.globe_tv_tree.column('name', width=210)
        self.globe_tv_tree.column('cat', width=140)
        self.globe_tv_tree.column('q', width=40, anchor='center')
        tvs = ttk.Scrollbar(tv_wrap, orient=VERTICAL, command=self.globe_tv_tree.yview)
        self.globe_tv_tree.configure(yscrollcommand=tvs.set)
        self.globe_tv_tree.grid(row=0, column=0, sticky='nsew')
        tvs.grid(row=0, column=1, sticky='ns')
        self.globe_tv_tree.bind('<Double-1>', lambda e: self.play_globe_tv_selected())

        ttk.Label(right, text='Radio stations in selected country', style='Muted.TLabel').grid(row=6, column=0, sticky='sw')
        radio_wrap = ttk.Frame(right)
        radio_wrap.grid(row=7, column=0, sticky='nsew', pady=(2, 6))
        radio_wrap.rowconfigure(0, weight=1)
        radio_wrap.columnconfigure(0, weight=1)
        self.globe_radio_tree = ttk.Treeview(radio_wrap, columns=('name','lang','bitrate'), show='headings', height=8)
        self.globe_radio_tree.heading('name', text='Station')
        self.globe_radio_tree.heading('lang', text='Language')
        self.globe_radio_tree.heading('bitrate', text='kbps')
        self.globe_radio_tree.column('name', width=210)
        self.globe_radio_tree.column('lang', width=120)
        self.globe_radio_tree.column('bitrate', width=60, anchor='center')
        rs = ttk.Scrollbar(radio_wrap, orient=VERTICAL, command=self.globe_radio_tree.yview)
        self.globe_radio_tree.configure(yscrollcommand=rs.set)
        self.globe_radio_tree.grid(row=0, column=0, sticky='nsew')
        rs.grid(row=0, column=1, sticky='ns')
        self.globe_radio_tree.bind('<Double-1>', lambda e: self.play_globe_radio_selected())

    def reset_globe(self):
        self.globe_lon0 = 0.0
        self.globe_lat0 = 15.0
        self.globe_zoom = 1.0
        self.redraw_globe()
        self.save_state()

    def zoom_globe(self, factor):
        self.globe_zoom = max(0.7, min(2.2, self.globe_zoom * factor))
        self.redraw_globe()
        self.save_state()

    def on_globe_wheel(self, event):
        self.zoom_globe(1.1 if event.delta > 0 else 0.9)

    def on_globe_press(self, event):
        self._drag_last = (event.x, event.y)
        self._skip_click = False

    def on_globe_drag(self, event):
        if not self._drag_last:
            return
        x0, y0 = self._drag_last
        dx, dy = event.x - x0, event.y - y0
        if abs(dx) + abs(dy) > 2:
            self._skip_click = True
        self.globe_lon0 = (self.globe_lon0 - dx * 0.45) % 360
        if self.globe_lon0 > 180:
            self.globe_lon0 -= 360
        self.globe_lat0 = max(-85, min(85, self.globe_lat0 + dy * 0.35))
        self._drag_last = (event.x, event.y)
        self.redraw_globe()

    def on_globe_release(self, event):
        self._drag_last = None
        self.save_state()

    def project_point(self, lon, lat, lon0, lat0):
        lam = math.radians(lon)
        phi = math.radians(lat)
        lam0 = math.radians(lon0)
        phi0 = math.radians(lat0)
        cosc = math.sin(phi0) * math.sin(phi) + math.cos(phi0) * math.cos(phi) * math.cos(lam - lam0)
        if cosc < -0.08:
            return None
        x = math.cos(phi) * math.sin(lam - lam0)
        y = math.cos(phi0) * math.sin(phi) - math.sin(phi0) * math.cos(phi) * math.cos(lam - lam0)
        return x, y

    def redraw_globe(self):
        c = self.globe_canvas
        if not c.winfo_exists():
            return
        w = max(c.winfo_width(), 400)
        h = max(c.winfo_height(), 300)
        c.delete('all')
        cx, cy = w / 2, h / 2
        r = min(w, h) * 0.42 * self.globe_zoom
        c.create_oval(cx-r, cy-r, cx+r, cy+r, fill=OCEAN, outline='#223040', width=2)
        self.draw_graticule(cx, cy, r)
        for feat in self.world_shapes:
            iso = (feat.get('iso_a2') or '').upper()
            name = feat.get('name') or iso
            tvc = self.tv_counts_by_iso.get(iso, 0)
            rc = self.radio_country_counts.get(iso, {}).get('count', 0)
            fill = self.country_fill_color(tvc, rc, iso == self.globe_selected_iso)
            outline = '#1b2026' if iso != self.globe_selected_iso else '#fff0bf'
            for poly in feat.get('polygons', []):
                for ring in poly[:1]:
                    pts = self.project_ring(ring, cx, cy, r)
                    if len(pts) >= 6:
                        item = c.create_polygon(pts, fill=fill, outline=outline, width=1, activeoutline=ACCENT, tags=('country', iso, name))
                        c.tag_bind(item, '<ButtonRelease-1>', lambda e, i=iso, n=name: self.on_country_click(e, i, n))
                        c.tag_bind(item, '<Enter>', lambda e, i=iso, n=name: self.on_country_hover(i, n))
        c.create_oval(cx-r, cy-r, cx+r, cy+r, outline='#41546a', width=1)
        c.create_text(cx, cy + r + 18, text='Drag to rotate • Mouse wheel to zoom', fill=MUTED, font=('Segoe UI', 10))

    def draw_graticule(self, cx, cy, r):
        c = self.globe_canvas
        for lat in range(-60, 90, 30):
            pts=[]
            for lon in range(-180, 181, 6):
                p = self.project_point(lon, lat, self.globe_lon0, self.globe_lat0)
                if p:
                    x,y=p; pts.extend([cx+r*x, cy-r*y])
            if len(pts) >= 4:
                c.create_line(*pts, fill=GRID, smooth=True)
        for lon in range(-150, 181, 30):
            pts=[]
            for lat in range(-89, 90, 4):
                p = self.project_point(lon, lat, self.globe_lon0, self.globe_lat0)
                if p:
                    x,y=p; pts.extend([cx+r*x, cy-r*y])
            if len(pts) >= 4:
                c.create_line(*pts, fill=GRID, smooth=True)

    def project_ring(self, ring, cx, cy, r):
        pts=[]
        for lon, lat in ring:
            p = self.project_point(lon, lat, self.globe_lon0, self.globe_lat0)
            if p is not None:
                x, y = p
                pts.extend([cx + r * x, cy - r * y])
        return pts

    def country_fill_color(self, tv_count, radio_count, selected=False):
        total = tv_count + radio_count
        if total <= 0:
            base = '#20242a'
        else:
            strength = min(1.0, math.log1p(total) / math.log(400))
            base = blend('#3a2d13', GOLD, 0.35 + 0.65 * strength)
        return blend(base, '#fff0bf', 0.25) if selected else base

    def on_country_hover(self, iso, name):
        tvc = self.tv_counts_by_iso.get(iso, 0)
        rc = self.radio_country_counts.get(iso, {}).get('count', 0)
        self.globe_hover_text.set(f'{name} ({iso}) • TV {tvc} • Radio {rc}')

    def on_country_click(self, event, iso, name):
        if self._skip_click:
            return
        self.globe_selected_iso = iso
        self.globe_selected_name = name
        self.globe_selected_text.set(f'{name} ({iso})')
        tvc = self.tv_counts_by_iso.get(iso, 0)
        rc = self.radio_country_counts.get(iso, {}).get('count', 0)
        self.globe_selected_counts.set(f'TV: {tvc} stream(s) • Radio: {rc} station(s)')
        self.populate_globe_tv_preview(iso)
        self.populate_globe_radio_preview([], loading=True)
        self.load_globe_radio_preview_async(iso)
        self.redraw_globe()

    def populate_globe_tv_preview(self, iso):
        items = [c for c in self.tv_channels if (c.country or '').upper() == iso]
        self.globe_tv_preview_items = items
        self.globe_tv_tree.delete(*self.globe_tv_tree.get_children())
        for idx, ch in enumerate(items[:500]):
            self.globe_tv_tree.insert('', END, iid=str(idx), values=(ch.name, ch.category_text[:40], ch.quality))

    def populate_globe_radio_preview(self, items, loading=False, note=None):
        self.globe_radio_preview_items = items
        self.globe_radio_tree.delete(*self.globe_radio_tree.get_children())
        if loading:
            self.globe_radio_tree.insert('', END, iid='0', values=('Loading…', '', ''))
            return
        if note:
            self.globe_radio_tree.insert('', END, iid='0', values=(note, '', ''))
            return
        for idx, st in enumerate(items[:500]):
            self.globe_radio_tree.insert('', END, iid=str(idx), values=(st.name, st.language[:20], st.bitrate))

    def play_globe_tv_selected(self):
        sel = self.globe_tv_tree.selection()
        if not sel:
            return
        ch = self.globe_tv_preview_items[int(sel[0])]
        try:
            play_url(ch.url)
            self.status_var.set(f'TV: {ch.name}')
        except FileNotFoundError:
            self.offer_vlc()

    def play_globe_radio_selected(self):
        sel = self.globe_radio_tree.selection()
        if not sel:
            return
        idx = sel[0]
        if not idx.isdigit():
            return
        st = self.globe_radio_preview_items[int(idx)]
        try:
            threading.Thread(target=self.radio_click_ping, args=(st.uuid,), daemon=True).start()
            play_url(st.url)
            self.status_var.set(f'Radio: {st.name}')
        except FileNotFoundError:
            self.offer_vlc()

    def load_globe_radio_preview_async(self, iso):
        self.globe_preview_request += 1
        token = self.globe_preview_request
        threading.Thread(target=self._globe_radio_preview_worker, args=(iso, token), daemon=True).start()

    def _globe_radio_preview_worker(self, iso, token):
        try:
            params = {'countrycode': iso, 'hidebroken': 'true', 'order': 'votes', 'reverse': 'true', 'limit': '500'}
            url = f"{RADIO_API}/json/stations/search?" + urllib.parse.urlencode(params)
            raw = http_json(url)
            stations=[]; seen=set()
            for x in raw:
                station_url=(x.get('url_resolved') or x.get('url') or '').strip()
                uid=(x.get('stationuuid') or station_url).strip()
                if not station_url or not uid or uid in seen:
                    continue
                seen.add(uid)
                stations.append(RadioStation(
                    uuid=uid,
                    name=(x.get('name') or 'Unnamed').strip(),
                    country=(x.get('country') or '').strip(),
                    countrycode=(x.get('countrycode') or '').strip(),
                    state=(x.get('state') or '').strip(),
                    language=(x.get('language') or '').strip(),
                    tags=(x.get('tags') or '').strip(),
                    codec=(x.get('codec') or '').strip(),
                    bitrate=int(x.get('bitrate') or 0),
                    url=station_url,
                    homepage=(x.get('homepage') or '').strip(),
                    favicon=(x.get('favicon') or '').strip(),
                    votes=int(x.get('votes') or 0),
                    clickcount=int(x.get('clickcount') or 0),
                ))
            self.msgq.put(('globe_radio_preview', (token, iso, stations, None)))
        except Exception as e:
            self.msgq.put(('globe_radio_preview', (token, iso, [], str(e))))

    def open_selected_country_tv(self):
        if not self.globe_selected_iso:
            return
        display = self.tv_country_name_by_iso.get(self.globe_selected_iso)
        if display and display in self.tv_country_box['values']:
            self.tv_country_var.set(display)
            self.apply_tv_filters()
        self.tabs.select(self.tv_tab)

    def open_selected_country_radio(self):
        if not self.globe_selected_iso:
            return
        prefix = f'{self.globe_selected_iso} — '
        for val in self.radio_country_box['values']:
            if isinstance(val, str) and val.startswith(prefix):
                self.radio_country_var.set(val)
                break
        self.tabs.select(self.radio_tab)
        self.load_radio_async(mode='country')

    # ---------- TV ----------

    def build_tv_tab(self):
        self.tv_search_var = StringVar(value=self.state.get('tv_search', ''))
        self.tv_country_var = StringVar(value=self.state.get('tv_country', 'ALL'))
        self.tv_category_var = StringVar(value=self.state.get('tv_category', 'ALL'))
        self.tv_hide_geo_var = BooleanVar(value=bool(self.state.get('tv_hide_geo', False)))
        self.tv_hide_not247_var = BooleanVar(value=bool(self.state.get('tv_hide_not247', False)))
        self.tv_info_var = StringVar(value='Velg en kanal.')

        controls = ttk.Frame(self.tv_tab)
        controls.pack(fill=X, pady=8)
        self.tv_search = ttk.Entry(controls, textvariable=self.tv_search_var)
        self.tv_search.pack(side=LEFT, fill=X, expand=True, padx=(0, 8))
        self.tv_search.bind('<KeyRelease>', lambda e: self.apply_tv_filters())
        self.tv_country_box = ttk.Combobox(controls, textvariable=self.tv_country_var, state='readonly', width=27)
        self.tv_country_box.pack(side=LEFT, padx=4)
        self.tv_country_box.bind('<<ComboboxSelected>>', lambda e: self.apply_tv_filters())
        self.tv_category_box = ttk.Combobox(controls, textvariable=self.tv_category_var, state='readonly', width=23)
        self.tv_category_box.pack(side=LEFT, padx=4)
        self.tv_category_box.bind('<<ComboboxSelected>>', lambda e: self.apply_tv_filters())
        ttk.Checkbutton(controls, text='Skjul geo', variable=self.tv_hide_geo_var, command=self.apply_tv_filters).pack(side=LEFT, padx=6)
        ttk.Checkbutton(controls, text='Skjul ikke-24/7', variable=self.tv_hide_not247_var, command=self.apply_tv_filters).pack(side=LEFT, padx=6)
        ttk.Button(controls, text='↻ Oppdater', command=lambda: self.load_tv_async(force=True)).pack(side=RIGHT, padx=4)
        ttk.Button(controls, text='＋ M3U', command=self.import_m3u).pack(side=RIGHT, padx=4)

        columns = ('fav','name','country','category','quality','labels')
        wrap = ttk.Frame(self.tv_tab)
        wrap.pack(fill=BOTH, expand=True)
        self.tv_tree = ttk.Treeview(wrap, columns=columns, show='headings', selectmode='browse')
        heads = {'fav':'★','name':'Kanal','country':'Land','category':'Kategori','quality':'Kvalitet','labels':'Merking'}
        widths = {'fav':45,'name':350,'country':190,'category':220,'quality':85,'labels':220}
        for col in columns:
            self.tv_tree.heading(col, text=heads[col])
            self.tv_tree.column(col, width=widths[col], anchor='center' if col in ('fav','quality') else 'w', stretch=(col not in ('fav','quality')))
        ys = ttk.Scrollbar(wrap, orient=VERTICAL, command=self.tv_tree.yview)
        xs = ttk.Scrollbar(wrap, orient=HORIZONTAL, command=self.tv_tree.xview)
        self.tv_tree.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
        self.tv_tree.grid(row=0, column=0, sticky='nsew')
        ys.grid(row=0, column=1, sticky='ns')
        xs.grid(row=1, column=0, sticky='ew')
        wrap.rowconfigure(0, weight=1)
        wrap.columnconfigure(0, weight=1)
        self.tv_tree.bind('<Double-1>', lambda e: self.play_tv())
        self.tv_tree.bind('<<TreeviewSelect>>', lambda e: self.update_tv_info())

        actions = ttk.Frame(self.tv_tab)
        actions.pack(fill=X, pady=8)
        ttk.Button(actions, text='▶ PLAY TV', style='Gold.TButton', command=self.play_tv).pack(side=LEFT, padx=(0, 5))
        ttk.Button(actions, text='★ / ☆ Favoritt', command=self.toggle_tv_favorite).pack(side=LEFT, padx=4)
        ttk.Button(actions, text='★ Vis favoritter', command=self.show_tv_favorites).pack(side=LEFT, padx=4)
        ttk.Button(actions, text='🌐 Nettside', command=self.open_tv_website).pack(side=LEFT, padx=4)
        ttk.Button(actions, text='⧉ Kopier URL', command=self.copy_tv_url).pack(side=LEFT, padx=4)
        ttk.Label(actions, textvariable=self.tv_info_var, style='Muted.TLabel').pack(side=LEFT, padx=12)

    def load_tv_async(self, force=False):
        if self.tv_loading:
            return
        self.tv_loading = True
        self.status_var.set('Laster verdens-TV …')
        threading.Thread(target=self._tv_worker, args=(force,), daemon=True).start()

    def _tv_worker(self, force):
        try:
            countries = fetch_tv_json('countries', force)
            categories = fetch_tv_json('categories', force)
            channels = fetch_tv_json('channels', force)
            streams = fetch_tv_json('streams', force)
            country_map = {x.get('code', ''): x.get('name', x.get('code', '')) for x in countries}
            category_map = {x.get('id', ''): x.get('name', x.get('id', '')) for x in categories}
            ch_map = {x.get('id'): x for x in channels if x.get('id') and not x.get('is_nsfw', False)}
            result=[]; seen=set()
            counts={}; display_by_iso={}
            for s in streams:
                cid = s.get('channel')
                if not cid or cid not in ch_map:
                    continue
                c = ch_map[cid]
                url = (s.get('url') or '').strip()
                if not url or (cid, url) in seen:
                    continue
                seen.add((cid, url))
                cc = (c.get('country') or 'XX').upper()
                cats = c.get('categories') or []
                display_by_iso[cc] = country_map.get(cc, cc)
                counts[cc] = counts.get(cc, 0) + 1
                result.append(TVChannel(
                    id=cid,
                    name=(s.get('title') or c.get('name') or cid).strip(),
                    country=cc,
                    country_name=country_map.get(cc, cc),
                    categories=[category_map.get(x, x) for x in cats],
                    url=url,
                    quality=s.get('quality') or '',
                    labels=s.get('labels') or [],
                    website=c.get('website') or '',
                    source='iptv-org',
                ))
            for item in read_json(CUSTOM_FILE, []):
                try:
                    t = TVChannel(**item)
                    result.append(t)
                    cc = (t.country or '').upper()
                    if cc and cc != 'CUSTOM':
                        counts[cc] = counts.get(cc, 0) + 1
                        display_by_iso[cc] = t.country_name or cc
                except Exception:
                    pass
            result.sort(key=lambda x: (x.country_name.casefold(), x.name.casefold()))
            self.msgq.put(('tv_loaded', (result, counts, display_by_iso)))
        except Exception as e:
            self.msgq.put(('error', ('TV', str(e))))

    def apply_tv_filters(self):
        q = normalize(self.tv_search_var.get())
        country = self.tv_country_var.get()
        category = self.tv_category_var.get()
        hide_geo = self.tv_hide_geo_var.get()
        hide_not247 = self.tv_hide_not247_var.get()
        items=[]
        for ch in self.tv_channels:
            if country != 'ALL' and ch.country_name != country:
                continue
            if category != 'ALL' and category not in ch.categories:
                continue
            labels_norm = {normalize(x) for x in ch.labels}
            if hide_geo and 'geo-blocked' in labels_norm:
                continue
            if hide_not247 and 'not 24/7' in labels_norm:
                continue
            hay = ' '.join([ch.name, ch.country_name, ch.category_text, ch.quality, ch.label_text, ch.id])
            if q and q not in normalize(hay):
                continue
            items.append(ch)
        self.tv_filtered = items
        self.tv_tree.delete(*self.tv_tree.get_children())
        for idx, ch in enumerate(items):
            fav = '★' if self.tv_fav_key(ch) in self.tv_favorites else ''
            self.tv_tree.insert('', END, iid=str(idx), values=(fav, ch.name, ch.country_name, ch.category_text, ch.quality, ch.label_text))
        self.status_var.set(f'TV: {len(items):,} / {len(self.tv_channels):,} streams')
        self.save_state()

    @staticmethod
    def tv_fav_key(ch):
        return f'{ch.id}|{ch.url}'

    def selected_tv(self):
        sel = self.tv_tree.selection()
        if not sel:
            return None
        try:
            return self.tv_filtered[int(sel[0])]
        except Exception:
            return None

    def play_tv(self):
        ch = self.selected_tv()
        if not ch:
            messagebox.showinfo(APP_NAME, 'Velg en TV-kanal først.')
            return
        try:
            play_url(ch.url)
            self.status_var.set(f'TV: {ch.name}')
        except FileNotFoundError:
            self.offer_vlc()

    def toggle_tv_favorite(self):
        ch = self.selected_tv()
        if not ch:
            return
        key = self.tv_fav_key(ch)
        if key in self.tv_favorites:
            self.tv_favorites.remove(key)
        else:
            self.tv_favorites.add(key)
        write_json(TV_FAV_FILE, sorted(self.tv_favorites))
        self.apply_tv_filters()

    def show_tv_favorites(self):
        q = [c for c in self.tv_channels if self.tv_fav_key(c) in self.tv_favorites]
        self.tv_filtered = q
        self.tv_tree.delete(*self.tv_tree.get_children())
        for idx, c in enumerate(q):
            self.tv_tree.insert('', END, iid=str(idx), values=('★', c.name, c.country_name, c.category_text, c.quality, c.label_text))
        self.status_var.set(f'TV-favoritter: {len(q)}')

    def update_tv_info(self):
        ch = self.selected_tv()
        self.tv_info_var.set('Velg en kanal.' if not ch else f'{ch.country_name} • {ch.category_text}')

    def open_tv_website(self):
        ch = self.selected_tv()
        if ch and ch.website:
            webbrowser.open(ch.website)

    def copy_tv_url(self):
        ch = self.selected_tv()
        if ch:
            self.copy_clipboard(ch.url, 'TV-stream URL kopiert')

    def import_m3u(self):
        path = filedialog.askopenfilename(title='Importer M3U/M3U8', filetypes=[('M3U playlist', '*.m3u *.m3u8'), ('Alle filer', '*.*')])
        if not path:
            return
        try:
            items = parse_m3u(Path(path))
            if not items:
                raise ValueError('Ingen kanaler funnet.')
            existing = read_json(CUSTOM_FILE, [])
            urls = {x.get('url') for x in existing}
            added = 0
            for x in items:
                if x['url'] not in urls:
                    existing.append(x)
                    urls.add(x['url'])
                    added += 1
            write_json(CUSTOM_FILE, existing)
            messagebox.showinfo(APP_NAME, f'Importert {added} nye TV/radio-streams i Custom M3U.')
            self.load_tv_async()
        except Exception as e:
            messagebox.showerror(APP_NAME, f'M3U-import feilet:\n{e}')

    # ---------- Radio ----------

    def build_radio_tab(self):
        self.radio_search_var = StringVar(value='')
        self.radio_country_var = StringVar(value='WORLD TOP')
        self.radio_tag_var = StringVar(value='')
        self.radio_hide_broken_var = BooleanVar(value=True)
        self.radio_info_var = StringVar(value='Velg en radiostasjon.')
        controls = ttk.Frame(self.radio_tab)
        controls.pack(fill=X, pady=8)
        self.radio_search = ttk.Entry(controls, textvariable=self.radio_search_var)
        self.radio_search.pack(side=LEFT, fill=X, expand=True, padx=(0, 8))
        self.radio_search.bind('<Return>', lambda e: self.load_radio_async(mode='search'))
        self.radio_country_box = ttk.Combobox(controls, textvariable=self.radio_country_var, state='readonly', width=28)
        self.radio_country_box['values'] = ['WORLD TOP']
        self.radio_country_box.pack(side=LEFT, padx=4)
        self.radio_country_box.bind('<<ComboboxSelected>>', lambda e: self.load_radio_async(mode='country'))
        self.radio_tag = ttk.Entry(controls, textvariable=self.radio_tag_var, width=20)
        self.radio_tag.pack(side=LEFT, padx=4)
        self.radio_tag.bind('<Return>', lambda e: self.load_radio_async(mode='search'))
        ttk.Checkbutton(controls, text='Skjul døde', variable=self.radio_hide_broken_var).pack(side=LEFT, padx=6)
        ttk.Button(controls, text='🔎 Søk', command=lambda: self.load_radio_async(mode='search')).pack(side=RIGHT, padx=4)
        ttk.Button(controls, text='🔥 World Top', command=lambda: self.load_radio_async(mode='top')).pack(side=RIGHT, padx=4)
        ttk.Button(controls, text='🌍 Radio Garden', command=lambda: webbrowser.open('https://radio.garden/')).pack(side=RIGHT, padx=4)

        columns = ('fav','name','country','state','language','tags','codec','bitrate','votes')
        wrap = ttk.Frame(self.radio_tab)
        wrap.pack(fill=BOTH, expand=True)
        self.radio_tree = ttk.Treeview(wrap, columns=columns, show='headings', selectmode='browse')
        heads = {'fav':'★','name':'Stasjon','country':'Land','state':'Region','language':'Språk','tags':'Tags','codec':'Codec','bitrate':'kbps','votes':'Stemmer'}
        widths = {'fav':45,'name':310,'country':160,'state':150,'language':140,'tags':250,'codec':75,'bitrate':70,'votes':75}
        for col in columns:
            self.radio_tree.heading(col, text=heads[col])
            self.radio_tree.column(col, width=widths[col], anchor='center' if col in ('fav','codec','bitrate','votes') else 'w', stretch=(col not in ('fav','codec','bitrate','votes')))
        ys = ttk.Scrollbar(wrap, orient=VERTICAL, command=self.radio_tree.yview)
        xs = ttk.Scrollbar(wrap, orient=HORIZONTAL, command=self.radio_tree.xview)
        self.radio_tree.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
        self.radio_tree.grid(row=0, column=0, sticky='nsew')
        ys.grid(row=0, column=1, sticky='ns')
        xs.grid(row=1, column=0, sticky='ew')
        wrap.rowconfigure(0, weight=1)
        wrap.columnconfigure(0, weight=1)
        self.radio_tree.bind('<Double-1>', lambda e: self.play_radio())
        self.radio_tree.bind('<<TreeviewSelect>>', lambda e: self.update_radio_info())

        actions = ttk.Frame(self.radio_tab)
        actions.pack(fill=X, pady=8)
        ttk.Button(actions, text='▶ PLAY RADIO', style='Gold.TButton', command=self.play_radio).pack(side=LEFT, padx=(0, 5))
        ttk.Button(actions, text='★ / ☆ Favoritt', command=self.toggle_radio_favorite).pack(side=LEFT, padx=4)
        ttk.Button(actions, text='★ Vis favoritter', command=self.show_radio_favorites).pack(side=LEFT, padx=4)
        ttk.Button(actions, text='🌐 Stasjonsside', command=self.open_radio_homepage).pack(side=LEFT, padx=4)
        ttk.Button(actions, text='⧉ Kopier stream', command=self.copy_radio_url).pack(side=LEFT, padx=4)
        ttk.Label(actions, textvariable=self.radio_info_var, style='Muted.TLabel').pack(side=LEFT, padx=12)

    def load_radio_countries_async(self):
        threading.Thread(target=self._radio_countries_worker, daemon=True).start()

    def _radio_countries_worker(self):
        try:
            data = http_json(f'{RADIO_API}/json/countries?hidebroken=true&order=name')
            self.msgq.put(('radio_countries', data))
        except Exception as e:
            self.msgq.put(('radio_note', f'Kunne ikke hente radioland: {e}'))

    def load_radio_async(self, mode='top'):
        if self.radio_loading:
            return
        self.radio_loading = True
        self.status_var.set('Laster verdensradio …')
        threading.Thread(target=self._radio_worker, args=(mode,), daemon=True).start()

    def _radio_worker(self, mode):
        try:
            hidebroken = 'true' if self.radio_hide_broken_var.get() else 'false'
            params = {'hidebroken': hidebroken, 'limit': '1000'}
            if mode == 'top':
                params.update({'order': 'votes', 'reverse': 'true', 'limit': '500'})
                url = f'{RADIO_API}/json/stations?' + urllib.parse.urlencode(params)
            elif mode == 'country':
                country = self.radio_country_var.get()
                if not country or country == 'WORLD TOP':
                    params.update({'order': 'votes', 'reverse': 'true', 'limit': '500'})
                    url = f'{RADIO_API}/json/stations?' + urllib.parse.urlencode(params)
                else:
                    cc = country.split(' — ', 1)[0].strip()
                    params.update({'countrycode': cc, 'order': 'votes', 'reverse': 'true'})
                    url = f'{RADIO_API}/json/stations/search?' + urllib.parse.urlencode(params)
            else:
                name = self.radio_search_var.get().strip()
                tag = self.radio_tag_var.get().strip()
                if name:
                    params['name'] = name
                if tag:
                    params['tag'] = tag
                params.update({'order': 'votes', 'reverse': 'true'})
                url = f'{RADIO_API}/json/stations/search?' + urllib.parse.urlencode(params)
            raw = http_json(url)
            stations=[]; seen=set()
            for x in raw:
                station_url=(x.get('url_resolved') or x.get('url') or '').strip()
                uid=(x.get('stationuuid') or station_url).strip()
                if not station_url or not uid or uid in seen:
                    continue
                seen.add(uid)
                stations.append(RadioStation(
                    uuid=uid,
                    name=(x.get('name') or 'Unnamed').strip(),
                    country=(x.get('country') or '').strip(),
                    countrycode=(x.get('countrycode') or '').strip(),
                    state=(x.get('state') or '').strip(),
                    language=(x.get('language') or '').strip(),
                    tags=(x.get('tags') or '').strip(),
                    codec=(x.get('codec') or '').strip(),
                    bitrate=int(x.get('bitrate') or 0),
                    url=station_url,
                    homepage=(x.get('homepage') or '').strip(),
                    favicon=(x.get('favicon') or '').strip(),
                    votes=int(x.get('votes') or 0),
                    clickcount=int(x.get('clickcount') or 0),
                ))
            self.msgq.put(('radio_loaded', stations))
        except Exception as e:
            self.msgq.put(('error', ('Radio', str(e))))

    def populate_radio(self, items):
        self.radio_filtered = list(items)
        self.radio_tree.delete(*self.radio_tree.get_children())
        for idx, s in enumerate(items):
            fav = '★' if s.uuid in self.radio_favorites else ''
            tags = s.tags[:80] + ('…' if len(s.tags) > 80 else '')
            self.radio_tree.insert('', END, iid=str(idx), values=(fav, s.name, s.country, s.state, s.language, tags, s.codec, s.bitrate, s.votes))
        self.status_var.set(f'Radio: {len(items):,} stasjoner')

    def selected_radio(self):
        sel = self.radio_tree.selection()
        if not sel:
            return None
        try:
            return self.radio_filtered[int(sel[0])]
        except Exception:
            return None

    def play_radio(self):
        s = self.selected_radio()
        if not s:
            messagebox.showinfo(APP_NAME, 'Velg en radiostasjon først.')
            return
        try:
            threading.Thread(target=self.radio_click_ping, args=(s.uuid,), daemon=True).start()
            play_url(s.url)
            self.status_var.set(f'Radio: {s.name}')
        except FileNotFoundError:
            self.offer_vlc()

    def radio_click_ping(self, uuid):
        try:
            http_json(f'{RADIO_API}/json/url/{urllib.parse.quote(uuid)}', timeout=8)
        except Exception:
            pass

    def toggle_radio_favorite(self):
        s = self.selected_radio()
        if not s:
            return
        if s.uuid in self.radio_favorites:
            self.radio_favorites.remove(s.uuid)
        else:
            self.radio_favorites.add(s.uuid)
        write_json(RADIO_FAV_FILE, sorted(self.radio_favorites))
        self.populate_radio(self.radio_filtered)

    def show_radio_favorites(self):
        q = [s for s in self.radio_stations if s.uuid in self.radio_favorites]
        self.populate_radio(q)
        self.status_var.set(f'Radio-favoritter i nåværende datasett: {len(q)}')

    def update_radio_info(self):
        s = self.selected_radio()
        if not s:
            self.radio_info_var.set('Velg en radiostasjon.')
            return
        parts = [x for x in [s.country, s.state, s.language, f'{s.codec} {s.bitrate}kbps'.strip()] if x]
        self.radio_info_var.set(' • '.join(parts))

    def open_radio_homepage(self):
        s = self.selected_radio()
        if s and s.homepage:
            webbrowser.open(s.homepage)

    def copy_radio_url(self):
        s = self.selected_radio()
        if s:
            self.copy_clipboard(s.url, 'Radio-stream URL kopiert')

    # ---------- shared ----------

    def offer_vlc(self):
        if messagebox.askyesno(APP_NAME, 'VLC ble ikke funnet.\n\nVil du åpne VLC sin nedlastingsside?'):
            webbrowser.open('https://www.videolan.org/vlc/')

    def copy_clipboard(self, text, status):
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self.status_var.set(status)

    def save_state(self):
        write_json(STATE_FILE, {
            'tv_search': self.tv_search_var.get(),
            'tv_country': self.tv_country_var.get(),
            'tv_category': self.tv_category_var.get(),
            'tv_hide_geo': self.tv_hide_geo_var.get(),
            'tv_hide_not247': self.tv_hide_not247_var.get(),
            'globe_lon0': self.globe_lon0,
            'globe_lat0': self.globe_lat0,
            'globe_zoom': self.globe_zoom,
        })

    def poll_queue(self):
        try:
            while True:
                kind, payload = self.msgq.get_nowait()
                if kind == 'tv_loaded':
                    self.tv_channels, self.tv_counts_by_iso, self.tv_country_name_by_iso = payload
                    self.tv_loading = False
                    country_names = sorted({c.country_name for c in self.tv_channels if c.country_name})
                    category_names = sorted({cat for c in self.tv_channels for cat in c.categories if cat})
                    self.tv_country_box['values'] = ['ALL'] + country_names + ['Custom M3U']
                    self.tv_category_box['values'] = ['ALL'] + category_names
                    if self.tv_country_var.get() not in self.tv_country_box['values']:
                        self.tv_country_var.set('ALL')
                    if self.tv_category_var.get() not in self.tv_category_box['values']:
                        self.tv_category_var.set('ALL')
                    self.apply_tv_filters()
                    self.redraw_globe()
                    if self.globe_selected_iso:
                        self.populate_globe_tv_preview(self.globe_selected_iso)
                elif kind == 'radio_countries':
                    self.radio_countries = payload
                    vals=['WORLD TOP']
                    counts={}
                    for x in payload:
                        cc=(x.get('iso_3166_1') or '').strip().upper()
                        name=(x.get('name') or '').strip()
                        count=int(x.get('stationcount') or 0)
                        if cc and name:
                            vals.append(f'{cc} — {name} ({count})')
                            counts[cc]={'name': name, 'count': count}
                    self.radio_country_counts = counts
                    self.radio_country_box['values'] = vals
                    self.redraw_globe()
                elif kind == 'radio_loaded':
                    self.radio_loading = False
                    self.radio_stations = payload
                    self.populate_radio(payload)
                elif kind == 'radio_note':
                    self.status_var.set(payload)
                elif kind == 'globe_radio_preview':
                    token, iso, stations, err = payload
                    if token != self.globe_preview_request or iso != self.globe_selected_iso:
                        continue
                    if err:
                        self.populate_globe_radio_preview([], loading=False, note='Radio preview failed')
                    else:
                        self.populate_globe_radio_preview(stations)
                elif kind == 'error':
                    section, err = payload
                    if section == 'TV':
                        self.tv_loading = False
                    else:
                        self.radio_loading = False
                    self.status_var.set(f'{section}: feil')
                    messagebox.showerror(APP_NAME, f'{section} kunne ikke lastes:\n\n{err}\n\nSjekk internett/VPN og prøv igjen.')
        except queue.Empty:
            pass
        self.root.after(120, self.poll_queue)


def main():
    ensure_dirs()
    root = Tk()
    App(root)
    root.mainloop()


if __name__ == '__main__':
    main()
