RAH WORLD MEDIA 10.0 — RAVEN LIVE DECK
========================================

Windows-first global media command deck built directly in Python/Tkinter. No Lovable.

NEW IN 10.0
-----------
• RAVEN LIVE DECK control layer on top of SUPER MODE.
• Save/load scene presets (country, scene, filters, globe layer, webcam theme, World Live).
• MY LIBRARY overview for TV/radio/webcam favorites, pinned places and presets.
• RAVEN REMOTE DECK: token-protected local web remote. Default can be this-PC only; LAN mode is explicit opt-in. Never port-forward it to the internet.
• DIAGNOSTICS.cmd plus in-app diagnostics: Python, VLC, writable data folder, remote port and public-source network checks.
• Media Wall HLS auto-recovery: retries failed preview/mosaic streams and replaces dead mosaic tiles when possible.
• Existing TV, Radio, Webcams, globe, World Live, Super Search, scenes, 4/6/9/12 mosaic, World Mix, health probes, history and pins retained.
• State migrates from state_v99.json to state_v10.json.

QUICK START
-----------
1. Extract the ZIP.
2. Double-click START-HER.cmd.
3. Try WORLD scene, MEDIA WALL, then mosaic 4.
4. Optional: REMOTE DECK, SAVE PRESET, MY LIBRARY, DIAGNOSTICS.

RUNNABLE FILES
--------------
START-HER.cmd   Main launcher.
SELFTEST.cmd    Python/tkinter compile + public-source smoke checks.
DIAGNOSTICS.cmd Runtime diagnostics and JSON report.
REPAIR.cmd      Helps install Python/VLC with Winget.
INSTALL.cmd     Installs to C:\RAH\WorldMedia\10.0 and creates shortcuts.
UNINSTALL.cmd   Removes installed program; keeps C:\RAH\IPTV user data.

REMOTE DECK SECURITY
--------------------
The remote uses a random secret token stored locally. LAN access is only enabled after an explicit confirmation. Use it only on a trusted home/local network. Do not expose or port-forward the remote port to the public internet.

PERFORMANCE
-----------
Hover previews remain capped. Mosaics start only after an explicit click. 12 streams can use substantial bandwidth/CPU/GPU; use 4 or 6 on older machines. Auto-recovery is bounded and does not aggressively scan the catalog.

SOURCES / LEGAL
---------------
TV: public iptv-org catalog. Radio: public Radio Browser mirrors. Webcams: optional Windy Webcams API v3 key. Playback follows Windows/network/VPN routing. No DRM, subscription, paywall or geo-control bypass.
