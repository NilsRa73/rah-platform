# RAH OS v0.9 Metallic Gold ISO Integration – R2 CANDIDATE

**Hva det er:** En integrasjonspakke som legger den godkjente RAH OS Metallic Desktop R1-stilen rett inn i kildefilene til en **ny** RAH OS v0.9 Debian 13 ISO-kandidat.

**Hva det ikke er:** Ikke en ferdig ISO. Ikke en Windows-temapakke. Ikke en oppdatering av v0.4 Stable eller den allerede nedlastede v0.9 ISO-en. Ingen komponenter er maskinvaretestet i denne pakken.

## RAH-design som bygges inn

- Opprinnelig, godkjent 5120x2160 metallic gold-bakgrunn (samme byte-innhold som R1).
- KDE Plasma-vinduspaletten `RAHOSMetallicGold`, systemmenyoppføring og mørk Konsole-profil.
- Offline RAH OS Command Deck; ingen brutte lenker til 127.0.0.1:18770.
- KDE Live-first-login: farger + bakgrunn forsøkes automatisk kun når Debian er startet som Live-system. Kjører som vanlig bruker; ingen sudo, disk-, boot- eller nettverksendringer.
- Brukeren kan åpne `RAH OS Metallic Command Deck` fra KDE-programmenyen.

## Slik brukes utviklingspakken (ikke installer på Windows)

**HOVED-PC Windows:** Ingen installasjon nødvendig. Denne ZIP-en er kildefiler for Linux ISO-bygget. Du trenger ikke pakke den ut for å bruke ditt nåværende Windows-tema.

**OMEN Debian / Linux-byggemaskin:** For å integrere i en separat Git-checkout som allerede har en kandidatgren:

```bash
bash STAGE-ISO-CANDIDATE.sh /path/to/rah-platform/rah-os
```

Bare navn `candidate/rah-os-*`, `feature/rah-os-*` og `experimental/rah-os-*` er tillatt. Scriptet stopper hvis filer allerede finnes med forskjellig innhold, eller hvis SHA-256 ikke stemmer. Bygger *ikke* ISO automatisk.

**Lenovo:** Ingen handling nå.

## Test uten ekte ISO

```bash
bash TEST-STAGING.sh
```

Denne testen simulerer et versjonert kildeprosjekt, verifiserer stable-main-beskyttelse, staging og KDE brukeroppstart med stubbet Plasma-API. Ikke en ekte full KDE/ISO/hardware-test.

## Neste reelle akseptansetester

1. Bygg ISO i separat GitHub-kandidatgren med eksisterende `rah-os/build.sh` og kontroller ferdig SquashFS for metadata, bakgrunn og autostart.
2. Boot ISO i VM: bekreft KDE-farger, bakgrunn, Konsole, meny og Command Deck.
3. Boot ISO på **OMEN** først; verifiser KDE og flere skjermer; kjør `rah-live-acceptance --gui`.
4. Stable Gate = OPEN inntil fysisk test og menneskelig gjennomgang av rapport.

**Ingen endringer i eksisterende v0.9-filen eller v0.4 Stable.**
