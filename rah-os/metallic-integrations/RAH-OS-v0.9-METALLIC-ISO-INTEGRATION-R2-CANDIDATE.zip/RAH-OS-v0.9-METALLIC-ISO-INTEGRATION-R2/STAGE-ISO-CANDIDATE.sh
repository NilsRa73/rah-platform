#!/usr/bin/env bash
set -Eeuo pipefail
# Apply only to an existing *candidate branch* rah-os directory. No builds or disk writes.
SELF="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ "$#" -ne 1 ]]; then
  echo 'Usage: bash STAGE-ISO-CANDIDATE.sh /path/to/rah-platform/rah-os' >&2
  exit 2
fi
TARGET="$(realpath -e "$1")"
[[ -f "$TARGET/build.sh" && -f "$TARGET/RAH-OS-VERSION.json" && -d "$TARGET/config" ]] || { echo '[FAIL] Not an existing RAH OS source tree';exit 3; }
[[ ! -L "$TARGET/config" ]] || { echo '[FAIL] Refusing symlink config';exit 4; }
REPO="$(git -C "$TARGET" rev-parse --show-toplevel 2>/dev/null)" || { echo '[FAIL] Target must be inside Git checkout';exit 5; }
BRANCH="$(git -C "$TARGET" symbolic-ref -q --short HEAD 2>/dev/null || true)"
case "$BRANCH" in
  candidate/rah-os-*|feature/rah-os-*|experimental/rah-os-*) ;;
  *) echo "[FAIL] Refusing branch '$BRANCH'. Create a separate candidate/rah-os-* branch first.";exit 6 ;;
esac
[[ "$(realpath "$REPO/rah-os")" == "$TARGET" ]] || { echo '[FAIL] Expected repo/rah-os source folder';exit 7; }
python3 - "$SELF" "$TARGET" "$BRANCH" <<'PY2'
from pathlib import Path
import sys,json,hashlib,shutil,os
self=Path(sys.argv[1]);target=Path(sys.argv[2]);branch=sys.argv[3]
manifest=json.loads((self/'payload-sha256.json').read_text())
version=json.loads((target/'RAH-OS-VERSION.json').read_text())
if not(str(version.get('version','')).startswith('0.9.') and version.get('stage')=='candidate'):
    raise SystemExit('[FAIL] Need v0.9 candidate; will not modify stable v0.4 or different releases')
if 'DIST="trixie"' not in (target/'build.sh').read_text():
    raise SystemExit('[FAIL] Builder is not expected Debian 13 trixie')
files=[]
for row in manifest['files']:
    src=self/'payload'/row['path'];dst=target/row['path']
    rel=Path(row['path'])
    if rel.is_absolute() or '..' in rel.parts or rel.parts[:2]!=('config','includes.chroot') or src.is_symlink():
        raise SystemExit('[FAIL] unsafe payload path')
    if not src.is_file() or hashlib.sha256(src.read_bytes()).hexdigest()!=row['sha256']:
        raise SystemExit('[FAIL] payload checksum mismatch: '+row['path'])
    if dst.is_symlink() or (dst.exists() and hashlib.sha256(dst.read_bytes()).hexdigest()!=row['sha256']):
        raise SystemExit('[FAIL] source collision, refusing overwrite: '+str(dst))
    files.append((src,dst))
# All files checked before writing any files. Existing identical candidate payload stays unchanged.
newfiles=[]
try:
    for src,dst in files:
        if not dst.exists():
            dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(src,dst)
            newfiles.append(dst)
    for _,dst in files:
        assert dst.is_file()
    status={'schema':'rah-os-metallic-staging-r2','branch':branch,'files_checked':len(files),'files_new':len(newfiles),'status':'STAGED_SOURCE_ONLY','iso_built':False,'live_boot_verified':False,'stable_gate':'OPEN'}
    (target/'RAH-OS-METALLIC-R2-STAGE-REPORT.json').write_text(json.dumps(status,indent=2)+'\n')
    print('[PASS] Candidate source staging:',len(files),'files checked,',len(newfiles),'new files')
    print('[PENDING] No ISO built; physical OMEN boot not tested; Stable Gate OPEN')
except Exception:
    for p in reversed(newfiles):
        p.unlink(missing_ok=True)
    raise
PY2
