# RAH Metallic R2 – målbare krav

- [ ] ISO CI-build og ferdig ISO SHA256 verificert (PENDING)
- [ ] KDE Plasma starter på Debian 13 i VM (PENDING)
- [ ] 5K wallpaper er synlig på skrivebordet (PENDING)
- [ ] KDE vinduer, Dolphin bruker RAH Metallic Gold farger (PENDING)
- [ ] Konsole `RAHOS` profil har mørk flate og gullfont (PENDING)
- [ ] KDE meny viser RAH OS Metallic Command Deck og åpner offline HTML (PENDING)
- [ ] Ingen lokal nettverksadresse vises som mislykket oppstart (kode verifisert for ingen hardkoding 18770)
- [ ] Live første innlogging gjør visualisering uten sudo og systemendringer (simulert med stubber)
- [ ] RAH v0.9 bootprofiler og Raven-tjenester er uendret (ikke endret av overlay)
- [ ] OMEN reell Live boot akseptanse (PENDING)

**Viktig**: README og dashboard kaller alltid denne løsningen CANDIDATE. Stable Gate OPEN.
