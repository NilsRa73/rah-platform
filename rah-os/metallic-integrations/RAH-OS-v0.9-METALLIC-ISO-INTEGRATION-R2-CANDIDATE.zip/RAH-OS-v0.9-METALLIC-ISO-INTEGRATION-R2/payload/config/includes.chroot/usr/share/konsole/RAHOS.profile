[Appearance]
ColorScheme=RAHOSMetallicGold
Font=DejaVu Sans Mono,12,-1,5,50,0,0,0,0,0
[General]
Name=RAH OS Metallic Gold
Parent=FALLBACK/
[Scrolling]
HistoryMode=2
