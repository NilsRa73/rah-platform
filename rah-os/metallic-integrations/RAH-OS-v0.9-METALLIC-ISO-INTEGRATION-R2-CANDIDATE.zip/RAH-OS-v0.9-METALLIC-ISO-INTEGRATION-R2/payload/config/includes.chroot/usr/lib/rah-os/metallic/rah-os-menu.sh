#!/usr/bin/env bash
set -Eeuo pipefail
BASE="/usr/share/rah-os/metallic"
DECK="$BASE/Shared/Deck/index.html"
function show_msg() { if command -v kdialog >/dev/null 2>&1; then kdialog --title 'RAH OS' --msgbox "$1"; else printf '\n%s\n' "$1"; fi; }
function open_if_found() { local tool="$1"; shift; if command -v "$tool" >/dev/null 2>&1; then "$tool" "$@" >/dev/null 2>&1 & else show_msg "Programmet $tool finnes ikke på denne Debian-installasjonen."; fi; }
if ! command -v kdialog >/dev/null 2>&1; then
  open_if_found xdg-open "$DECK"; exit 0
fi
choice=$(kdialog --title 'RAH OS — Metallic Command Deck' --geometry 600x480 --menu 'Velg hva du vil åpne:' \
  1 'RAH OS — GOLD dashboard (offline)' \
  2 'Dolphin — Filer' \
  3 'RAH Terminal — Konsole GOLD' \
  4 'KDE Systeminnstillinger' \
  5 'Firefox nettleser' \
  6 'RAH Live Acceptance (hvis installert)' \
  7 'RAH OS lokal status' 2>/dev/null) || exit 0
case "$choice" in
  1) open_if_found xdg-open "$DECK" ;;
  2) open_if_found dolphin "$HOME" ;;
  3) open_if_found konsole --profile RAHOS ;;
  4) open_if_found systemsettings ;;
  5) if command -v firefox-esr >/dev/null 2>&1; then open_if_found firefox-esr; else open_if_found firefox; fi ;;
  6) if command -v rah-live-acceptance >/dev/null 2>&1; then
       rah-live-acceptance --gui >/dev/null 2>&1 &
     else show_msg 'Live Acceptance finnes ikke her. Programmet er normalt tilgjengelig på RAH OS Live.'; fi ;;
  7) if command -v rah-node-readiness >/dev/null 2>&1; then
       # Safe read-only status, shown in Konsole to keep output readable.
       if command -v konsole >/dev/null 2>&1; then konsole --profile RAHOS -e rah-node-readiness >/dev/null 2>&1 &
       else show_msg 'Konsollprogrammet Konsole mangler.'; fi
     else show_msg 'RAH-node-readiness er ikke installert. Ingen status blir funnet på.'; fi ;;
esac
