#!/usr/bin/env bash
set -Eeuo pipefail
SELF="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TMP="$(mktemp -d /tmp/rah-metallic-r2-XXXXXX)";trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/repo/rah-os/config";cd "$TMP/repo"
git init -q -b main;git config user.email rah-test@example.invalid;git config user.name RAH-Test
cat > rah-os/build.sh <<'EOF'
#!/usr/bin/env bash
DIST="trixie"
EOF
printf '{"version":"0.9.0","stage":"candidate"}\n' > rah-os/RAH-OS-VERSION.json
git add .;git commit -qm 'isolated mock source'
# A stable/main branch MUST be rejected; no overlay files may be copied.
if bash "$SELF/STAGE-ISO-CANDIDATE.sh" "$TMP/repo/rah-os" >"$TMP/reject.txt" 2>&1; then echo 'FAIL: staging allowed on main';exit 1;fi
if [[ -e rah-os/config/includes.chroot ]]; then echo 'FAIL: stable branch was modified';exit 1;fi
echo '[PASS] STABLE BRANCH PROTECTED'
git checkout -qb candidate/rah-os-metallic-r2
bash "$SELF/STAGE-ISO-CANDIDATE.sh" "$TMP/repo/rah-os"
bash "$SELF/STAGE-ISO-CANDIDATE.sh" "$TMP/repo/rah-os"
python3 - "$TMP/repo/rah-os" "$SELF" <<'PY2'
import pathlib,sys,json,hashlib
root=pathlib.Path(sys.argv[1]);self=pathlib.Path(sys.argv[2]);manifest=json.loads((self/'payload-sha256.json').read_text())
assert len(manifest['files'])>=10
for o in manifest['files']:
 p=root/o['path'];assert p.is_file();assert hashlib.sha256(p.read_bytes()).hexdigest()==o['sha256']
assert (root/'RAH-OS-METALLIC-R2-STAGE-REPORT.json').exists()
print('[PASS] MANIFEST AND REPEAT STAGING')
PY2
# Stub KDE commands; exercise exact first-login program logic with fake HOME/asset root.
mkdir -p "$TMP/home/.config" "$TMP/bin"
printf '[General]\nColorScheme=BreezeDark\n' > "$TMP/home/.config/kdeglobals"
for app in plasma-apply-colorscheme qdbus6; do cat > "$TMP/bin/$app" <<'EOF'
#!/bin/sh
exit 0
EOF
chmod +x "$TMP/bin/$app";done
mkdir -p "$TMP/apply"
chmod -R 777 "$TMP/home" "$TMP/apply"
# Use nobody to simulate the ordinary KDE user; don't execute root-only firstlogin.
chmod 755 "$TMP" "$TMP/bin" "$TMP/repo" "$TMP/repo/rah-os" "$TMP/repo/rah-os/config" "$TMP/repo/rah-os/config/includes.chroot"
runuser -u nobody -- env HOME="$TMP/home" XDG_STATE_HOME="$TMP/apply" RAH_OS_METALLIC_TEST_MODE=1 RAH_OS_METALLIC_TEST_ASSET_ROOT="$TMP/repo/rah-os/config/includes.chroot/usr/share/rah-os/metallic" PATH="$TMP/bin:$PATH" bash "$TMP/repo/rah-os/config/includes.chroot/usr/local/bin/rah-os-metallic-first-login"
grep -q 'OVERALL: CONFIGURED_IN_LIVE_USER_SESSION' "$TMP/apply/rah-os/metallic-r2/first-login.txt"
test -e "$TMP/apply/rah-os/metallic-r2/ready"
grep -q BreezeDark "$TMP/apply/rah-os/metallic-r2/kdeglobals.original"
echo '[PASS] LIVE USER FIRST LOGIN (KDE API STUBBED)'
for f in $(find "$SELF" -name '*.sh' -type f); do bash -n "$f";done
bash -n "$SELF/payload/config/includes.chroot/usr/local/bin/rah-os-metallic-first-login"
bash -n "$SELF/payload/config/includes.chroot/usr/local/bin/rah-os-metallic-deck"
bash -n "$SELF/payload/config/includes.chroot/usr/lib/rah-os/metallic/rah-os-menu.sh"
echo '[PASS] SHELL SYNTAX'
